const express = require('express')
const app = express()


const mongoose=require('mongoose')
// middlewares
app.use(express.static('view')) //je folder me html and controller hoy a folder nu name
app.use(express.urlencoded({extended:true})) //from frontend to back end data url through data jode manipulation thay che
app.use(express.json()) //access je mongo mathi kriye chhiye data a properly json format ma kre che ,normal string format ma data handle nai krtu


//connection

mongoose.connect("mongodb://localhost:27017/MCA064")   //END MA DATABASE NU NAME AAPVANU...COLLECTION NU NAME NAI..COPY KRO MONGO MATHI CONNECTION STRING
//Aa database na aapde multiple connection we will use..!


//to check wheather we are connected with mongodb or not

const conn = mongoose.connection
conn.on('connected', () => {
    console.log('Mongodb connected')
})   //node app.js krine we can check wheather mongo is connected or not

//creating schema
const userSchema = mongoose.Schema({
  uid:String,
  password:String,
  role:String,
  age:Number,
  contact:Number
})
 
const userclone = mongoose.model('users', userSchema) 
 console.log(userclone.find()) //to check model.find() method   //data display nai kre info related to table show krse


app.get('/home',(req,res)=>{
    res.sendFile(__dirname+'view/index.html')
}) 

app.get('/api/getd', (req, res) => { 
    userclone.find().then((data) => { res.json(data)})
})

app.post('/api/addd',(req,res)=>{
 userclone.create({
            uid:req.body.uid,
            password:req.body.upass,
            role:req.body.urole,
            age:req.body.uage,
            contact:req.body.uctc
    }).then((newuser) => {
        console.log(newuser)
         res.json({message:'User Added'})
   })
})


app.listen(2024,()=>{
    console.log("Server is running on port 2024  index.html ")
})