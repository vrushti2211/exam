const userModule = angular.module('uApp',[])
userModule.controller('uCtrl', function ($scope, $http) {
    $scope.udata = []
    $scope.newuser={}

 $scope.getdet = function(){
        $http.get('/api/getd').then(function(response){
            $scope.udata=response.data;
        })
    }
     $scope.adddet = function(){
        $http.post('/api/addd',$scope.newuser).then(function(response){
            $scope.msg = response.data.message
        })
       $scope.getdet()
    }

    $scope.getdet()
})