def split_into_bins(elements, bin_size):
    bins = [elements[i:i + bin_size] for i in range(0, len(elements), bin_size)]
    return bins

def binning_by_minmax(elements, bin_size):
    bins = split_into_bins(elements, bin_size)

    for bin_idx, bin in enumerate(bins):
        min_ele = min(bin)
        max_ele = max(bin)
        bins[bin_idx] = [min_ele if abs(x - min_ele) <= abs(x - max_ele) else max_ele for x in bin]

    return [item for sublist in bins for item in sublist]

def binning_by_means(elements, bin_size):
    bins = split_into_bins(elements, bin_size)

    for bin_idx, bin in enumerate(bins):
        mean_value = sum(bin) / len(bin)
        bins[bin_idx] = [round(mean_value,2)] * len(bin)

    return [item for sublist in bins for item in sublist]

elements = [2, 5, 7, 5, 3, 6, 8, 9, 10, 12, 15, 16, 18, 22, 99]
bin_size = 3

a = binning_by_minmax(elements, bin_size)
b = binning_by_means(elements, bin_size)

print("Min-Max Binning:", a)
print("Mean Binning:", b)
