# Initialize variables
i1 = []
k = 4  # Number of clusters
k1 = []
k2 = []
k3 = []
k4 = []
n = input("Enter number of elements: ")
n = int(n)

# Input elements
for i in range(n):
    t = input("Enter value: ")
    t = int(t)
    i1.append(t)

# Distributing items into initial clusters
i = 0
while i < n:
    k1.append(i1[i])
    if i + 1 < n:
        k2.append(i1[i + 1])
    if i + 2 < n:
        k3.append(i1[i + 2])
    if i + 3 < n:
        k4.append(i1[i + 3])
    i += 4

print("Initial Clusters:")
print("Cluster 1:", k1)
print("Cluster 2:", k2)
print("Cluster 3:", k3)
print("Cluster 4:", k4)

# Calculate means
k1m = sum(k1) / len(k1) if k1 else 0
k2m = sum(k2) / len(k2) if k2 else 0
k3m = sum(k3) / len(k3) if k3 else 0
k4m = sum(k4) / len(k4) if k4 else 0

# Clustering process
swap = True
while swap:
    swap = False
    for cluster, mean in zip([k1, k2, k3, k4], [k1m, k2m, k3m, k4m]):
        for item in cluster[:]:  # Iterate over a copy of the cluster
            distances = [abs(item - mean) for mean in [k1m, k2m, k3m, k4m]]
            min_distance = min(distances)
            target_cluster_index = distances.index(min_distance)

            if target_cluster_index != [k1, k2, k3, k4].index(cluster):
                # Move item to the target cluster
                cluster.remove(item)
                [k1, k2, k3, k4][target_cluster_index].append(item)
                swap = True

    # Recalculate means
    k1m = sum(k1) / len(k1) if k1 else 0
    k2m = sum(k2) / len(k2) if k2 else 0
    k3m = sum(k3) / len(k3) if k3 else 0
    k4m = sum(k4) / len(k4) if k4 else 0

print("Final Clusters:")
print("Cluster 1:", k1)
print("Cluster 2:", k2)
print("Cluster 3:", k3)
print("Cluster 4:", k4)
