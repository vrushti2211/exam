const appModule = angular.module("app1",[])
appModule.controller("myCtrl",function($scope,$http){
    $scope.Data=[]   //array variable to display MULTIPLE OBJECTS
    $scope.newdata={}   //object type variable to insert SINGLE OBJECTS key value pair
    $scope.stat = 0;


     // $scope.check=10;
     $scope.editStat=false;
     
     // Function to read data
     $scope.getDetails = function(){
        $http.get('/api/users').then(function(response){
            $scope.Data=response.data;
        })
    }
    $scope.getDetails()

    $scope.addDetails = function(newdata){
        $http.post('/api/adds',newdata).then((response)=>{
            $scope.msg = response.data.message
        })
        $scope.getDetails()
    }

    $scope.deleteDetails = function(id){
        $http.delete(`/api/deletes/${id}`).then((response)=>{
            $scope.msg = response.data.message
        })
        $scope.getDetails()
    }
    $scope.edit = function(item){
        $scope.editStat=true;
        $scope.editItem = item
        $scope.newdata.ID = $scope.editItem.ID
        $scope.newdata.pass = $scope.editItem.pass
        $scope.newdata.role = $scope.editItem.role
        $scope.newdata.gender = $scope.editItem.gender
        $scope.newdata.course = $scope.editItem.course
        $scope.newdata.hobbyReading = $scope.editItem.hobbyReading
        $scope.newdata.hobbySports = $scope.editItem.hobbySports
        $scope.newdata.hobbyMusic = $scope.editItem.hobbyMusic
        $scope.newdata.q = $scope.editItem.q
        $scope.newdata.p = $scope.editItem.p


        $scope.stat=1
    }

    $scope.updateDetails = function(upItem){
        $http.put(`/api/updates/${upItem.ID}`,upItem).then((response)=>{
            $scope.msg = response.data.message
        })
        $scope.getDetails()
    }


})