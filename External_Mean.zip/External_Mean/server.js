const express = require('express')
const app = express()
const mongoose = require('mongoose')
// middlewares
app.use(express.static('public'))
app.use(express.urlencoded({extended:true}))
app.use(express.json())

//connection
mongoose.connect("mongodb://0.0.0.0:27017/external")
//Checking Connection string
const conn = mongoose.connection
conn.on('connected',()=>{
    console.log('MongoDB Connected')
})

// Creating Schema
const Schemaa = mongoose.Schema({
    ID:String,
    pass:String,
    role: String,
    gender: String,
    course: String,
    hobbyReading: String,
    hobbySports: String,
    hobbyMusic: String,
    q: Number,
    p: Number
    
})

// Create Model
const cmodel = mongoose.model('Collection1',Schemaa)

app.get('/', (req, res) => {
    res.sendFile(__dirname+'/public/index.html')
})


// API :View Data
app.get('/api/users',(req,res)=>{
    cmodel.find().then((data)=>{
        res.json(data)
    })
})

//API: Insert Data
app.post('/api/adds',(req,res)=>{
    cmodel.create({
        ID:req.body.ID,
        pass:req.body.pass,
        role: req.body.role,
        gender: req.body.gender,
        course: req.body.course,
        hobbyReading: req.body.hobbyReading,
        hobbySports: req.body.hobbySports,
        hobbyMusic: req.body.hobbyMusic,
        q:req.body.q,
        p:req.body.p
        
    }).then(()=>{
        res.json({message:'Data Added'})
    })
})


//API : delete data
app.delete('/api/deletes/:id1',(req,res)=>{
    let id = req.params.id1
    cmodel.deleteOne({ID:id}).then((err,data)=>{
        res.json({message:`Data ${id} deleted`})
    })
})

//API : update data
app.put('/api/updates/:id1',(req,res)=>{
    let id = req.params.id1
    let upItem = req.body
    cmodel.updateOne({ID:id},upItem).then((data)=>{
        res.json({message:`Data ${id} edited`})
    })
})


app.listen(2010,()=>{
    console.log("Server is running on the port 2010")
    console.log("http://localhost:2010")
})