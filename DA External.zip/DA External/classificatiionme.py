
train_data = [
    ["FC", "SC", "SC", 'Y'],
    ["SC", "PC", "PC", 'N'],
    ["SC", "SC", "SC", 'Y'],
    ["SC", "SC", "PC", 'N']
]


rule_a = {1: "HSC=FC", 2: "Grad=SC", 3: "PG=SC", 4: "Y"}
rule_b = {1: "HSC=SC", 2: "Grad=PC", 3: "PG=PC", 4: "N"}
rule_c = {1: "HSC=SC", 2: "Grad=SC", 3: "PG=SC", 4: "Y"}

rules = [rule_a, rule_b, rule_c]


test_data = [
    ["FC", "SC", "SC", '?'],
    ["SC", "PC", "PC", '?'],
    ["SC","SC","SC","?"]
]

def classify(instance, rules):
    for rule in rules:
        
        matches = True
        for key in [1, 2, 3]:
            if key == 1 and rule[key] != f"HSC={instance[0]}":
                matches = False
                break
            if key == 2 and rule[key] != f"Grad={instance[1]}":
                matches = False
                break
            if key == 3 and rule[key] != f"PG={instance[2]}":
                matches = False
                break
        
        if matches:
            return rule[4]
    
    return "Unknown"

for instance in test_data:
    classification = classify(instance, rules)
    print(f"Test instance {instance} classified as: {classification}")
