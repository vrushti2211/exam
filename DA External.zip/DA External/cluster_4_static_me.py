i1 = []
k = 4
k1 = []
k2 = []
k3 = []
k4 = []
n = input("Enter number of elements : ")
n = int(n)
for i in range(n):
    t = input("Enter value : ")
    t = int(t)
    i1.append(t)

i = 0
while(i < n):
    k1.append(i1[i])
    if(i + 1 < n):
        k2.append(i1[i + 1])
    if(i + 2 < n):
        k3.append(i1[i + 2])
    if(i + 3 < n):
        k4.append(i1[i + 3])
    i = i + 4

print(i1)
print(k1)
print(k2)
print(k3)
print(k4)

k1m = sum(k1) / len(k1)
k2m = sum(k2) / len(k2)
k3m = sum(k3) / len(k3)
k4m = sum(k4) / len(k4)
swap = True
while(swap):
    swap = False
    for i in k1:
        d1 = abs(i - k1m)
        d2 = abs(i - k2m)
        d3 = abs(i - k3m)
        d4 = abs(i - k4m)
        if((d1 < d2) and (d1 < d3) and (d1 < d4)):
            print(str(i) + " is correctly placed in a given cluster")
        elif(d2 < d3 and d2 < d4):
            temp = k1.remove(i)
            k2.append(i)
            swap = True
        elif(d3 < d4):
            temp = k1.remove(i)
            k3.append(i)
            swap = True
        else:
            temp = k1.remove(i)
            k4.append(i)
            swap = True

    for i in k2:
        d1 = abs(i - k1m)
        d2 = abs(i - k2m)
        d3 = abs(i - k3m)
        d4 = abs(i - k4m)
        if((d2 < d1) and (d2 < d3) and (d2 < d4)):
            print(str(i) + " is correctly placed in a given cluster")
        elif(d1 < d3 and d1 < d4):
            temp = k2.remove(i)
            k1.append(i)
            swap = True
        elif(d3 < d4):
            temp = k2.remove(i)
            k3.append(i)
            swap = True
        else:
            temp = k2.remove(i)
            k4.append(i)
            swap = True

    for i in k3:
        d1 = abs(i - k1m)
        d2 = abs(i - k2m)
        d3 = abs(i - k3m)
        d4 = abs(i - k4m)
        if((d3 < d1) and (d3 < d2) and (d3 < d4)):
            print(str(i) + " is correctly placed in a given cluster")
        elif(d1 < d2 and d1 < d4):
            temp = k3.remove(i)
            k1.append(i)
            swap = True
        elif(d2 < d4):
            temp = k3.remove(i)
            k2.append(i)
            swap = True
        else:
            temp = k3.remove(i)
            k4.append(i)
            swap = True

    for i in k4:
        d1 = abs(i - k1m)
        d2 = abs(i - k2m)
        d3 = abs(i - k3m)
        d4 = abs(i - k4m)
        if((d4 < d1) and (d4 < d2) and (d4 < d3)):
            print(str(i) + " is correctly placed in a given cluster")
        elif(d1 < d2 and d1 < d3):
            temp = k4.remove(i)
            k1.append(i)
            swap = True
        elif(d2 < d3):
            temp = k4.remove(i)
            k2.append(i)
            swap = True
        else:
            temp = k4.remove(i)
            k3.append(i)
            swap = True

    k1m = sum(k1) / len(k1)
    k2m = sum(k2) / len(k2)
    k3m = sum(k3) / len(k3)
    k4m = sum(k4) / len(k4)

print(i1)
print(k1)
print(k2)
print(k3)
print(k4)
