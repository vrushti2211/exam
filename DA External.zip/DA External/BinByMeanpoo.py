# Get user input for the number of values
num_values = int(input("Enter the number of values: "))
 
# Get user input for the actual values
data = []
print("Enter the values one by one:")
for _ in range(num_values):
    value = int(input())
    data.append(value)
 
# Get user input for the number of bins
num_bins = int(input("Enter the number of bins: "))
 
# Calculate the bin size
bin_size = len(data) // num_bins
 
# Divide the data into bins
bins = [data[i * bin_size: (i + 1) * bin_size] for i in range(num_bins)]
 
# Add leftover items to the last bin if data cannot divide evenly
if len(data) % num_bins != 0:
    bins[-1].extend(data[num_bins * bin_size:])
 
# Binning by Mean
binned_by_mean = []
for bin_ in bins:
    mean = sum(bin_) // len(bin_)
    binned_by_mean.append([mean] * len(bin_))
 
# Print Results
print("\nOriginal Data:", data)
print("\nBins:", bins)
print("\nBinned by Mean:", binned_by_mean)
