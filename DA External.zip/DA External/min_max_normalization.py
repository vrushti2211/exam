def min_max_normalize():
    old_min = int(input("Enter the minimum value of old range:"))
    old_max = int(input("Enter the maximum value of old range:"))
    new_min = int(input("Enter the minimum value of new range:"))
    new_max = int(input("Enter the maximum value of new range:"))
    old_value = int(input(f"Enter the value for convert in range ({new_min}-{new_max}):"))
    normalized_value = ((old_value - old_min) / (old_max - old_min)) * (new_max - new_min) + new_min
    return round(normalized_value,2)

print(min_max_normalize())