def mean(data: list): 
    ans = sum(data)/len(data)
    return round(ans,2)

def mode(data: list):
    count_data = {}
    for i in data:
        if i not in count_data:
            count_data[i] = 1
        else:
            count_data[i] += 1
    max_count = max(count_data.values())
    modes = [num for num, freq in count_data.items() if freq == max_count]
    return modes

def median(data: list):
    data.sort()
    length = len(data)
    if length % 2 == 0:
        mid1 = length // 2
        mid2 = mid1 - 1
        median_val = (data[mid1] + data[mid2]) / 2
    else:
        median_val = data[length // 2]
    return median_val

data = [1,4,5,6,7,8,9,10,11,12,13,11,12,14,15]
print(mean(data))
print(mode(data))
print(median(data))
