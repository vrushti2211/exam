attributes = ("Apti","Comm","Grad","GradP","Placed")
val = ("Yes/No","G/A/B","BCA/BSCIT/BCOM","FC/SC/PC","Yes/No")
data = [
    ["Yes","G","BSCIT","FC","Yes"],
    ["No","B","BCOM","PC","No"],
    ["Yes","A","BCA","SC","Yes"],
    ["Yes","B","BSCIT","SC","NO"],
    ["Yes","A","BCOM","SC","YES"],
    ["No","A","BCA","FC","Yes"],
    ["Yes","A","BCOM","PC","No"]]
rules = {
    1: {"Apti":"Yes","Comm":"G","Placed":"Yes"},
    2: {"Apti":"Yes","Comm":"A","GradP":"FC","Placed":"Yes"},
    3: {"Apti":"Yes","Comm":"B","Placed":"No"},
    4: {"Apti":"No","Comm":"A","Placed":"Yes"},
    5: {"Grad":"BCOM","GradP":"FC","Placed":"Yes"},
    6: {"Apti":"Yes","Comm":"B","GradP":"PC","Placed":"No"},
    7: {"Apti":"Yes/No","Grad":"BCA","Placed":"Yes"}
}
def train_data(attributes, data):
    input_data = {}
    
    for attri, val in zip(attributes, data):
        input_data[attri] = val
    
    for rule_id, conditions in rules.items():
        match = True
        for attr, expected_value in conditions.items():
            if '/' in expected_value:
                expected_values = expected_value.split('/')
                if input_data[attr] not in expected_values:
                    match = False
                    break
            else:
                if input_data[attr] != expected_value:
                    match = False
                    break
        
        if match:
            return f"Rule {rule_id} matched"

    return "No match found"

test_data = [
    ["Yes", "G", "BSCIT", "FC"],
    ["No", "A", "BCA", "FC"],
    ["Yes", "B", "BCOM", "PC"],
    ["Yes", "A", "BCA", "SC"],
    ["Yes", "B", "BCOM", "SC"],
    ["No", "A", "BCOM", "FC"],  
    ["Yes", "G", "BSCIT", "PC"],
    ["No", "A", "BSCIT", "FC"],
    ["Yes", "A", "BCA", "FC"],
    ["Yes", "B", "BCA", "SC"]
]

data = ["Yes", "G", "BSCIT", "FC",'?']
for i in test_data:
    print(f"Input: {i}, Prediction: {train_data(attributes, i)}")
    print("--------------------")
