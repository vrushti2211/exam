# Get user input for the number of values
num_values = int(input("Enter the number of values: "))
 
# Get user input for the actual values
data = []
print("Enter the values one by one:")
for _ in range(num_values):
    value = int(input())
    data.append(value)
 
# Get user input for the number of bins
num_bins = int(input("Enter the number of bins: "))
 
# Calculate the bin size
bin_size = len(data) // num_bins
 
# Divide the data into bins
bins = [data[i * bin_size: (i + 1) * bin_size] for i in range(num_bins)]
 
# Add leftover items to the last bin if data cannot divide evenly
if len(data) % num_bins != 0:
    bins[-1].extend(data[num_bins * bin_size:])
 
# Binning by Boundaries
binned_by_boundaries = []
 
for bin_ in bins:
    lower, upper = min(bin_), max(bin_)  # Find boundaries of the bin
    binned_bin = [lower if abs(x - lower) <= abs(x - upper) else upper for x in bin_]  # Replace values
    binned_by_boundaries.append(binned_bin)
 
# Print Results
print("\nOriginal Data:", data)
print("\nBins:", bins)
print("\nBoundaries:", [(min(bin_), max(bin_)) for bin_ in bins])
print("\nBinned by Boundaries:", binned_by_boundaries)









'''for bin_ in bins:
    lower = min(bin_)  # Find the lower boundary
    upper = max(bin_)  # Find the upper boundary
    binned_bin = []  # Create an empty list for the binned values
 
    # Loop through each value in the bin and replace it with the nearest boundary
    for x in bin_:
        if abs(x - lower) <= abs(x - upper):
            binned_bin.append(lower)
        else:
            binned_bin.append(upper)
 
    binned_by_boundaries.append(binned_bin)'''
