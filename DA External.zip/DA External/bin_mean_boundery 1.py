data = []
n = int(input("Enter the number of elements: "))
for i in range(n):
    value = int(input("Enter value : "))
    data.append(value)

data.sort()

bin_size = int(input("Enter the bin size: "))

# Bin by Mean
mean_binned_data = []
i = 0
while i < len(data):
    bin_values = data[i:i + bin_size]
    mean_value = sum(bin_values) / len(bin_values)
    for value in bin_values:
        mean_binned_data.append(mean_value)
    i += bin_size

# Bin by Boundary
boundary_binned_data = []
i = 0
while i < len(data):
    bin_values = data[i:i + bin_size]
    min_value = min(bin_values)
    max_value = max(bin_values)
    
    for value in bin_values:
        if abs(value - min_value) < abs(value - max_value):
            boundary_binned_data.append(min_value)
        else:
            boundary_binned_data.append(max_value)
    
    i += bin_size

# Print the results
print("Original Data:", data)
print("Binned by Mean:", mean_binned_data)
print("Binned by Boundary:", boundary_binned_data)
