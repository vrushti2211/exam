i1 = []
k = 3
k1 = []
k2 = []
k3 = []
n = input("Enter number of elements : ")
n = int(n)
for i in range(n):
    t = input("Enter value : ")
    t = int(t)
    i1.append(t)
    
i = 0
while(i<n):
    k1.append(i1[i])
    if(i + 1 < n):
        k2.append(i1[i + 1])
    if(i + 2 < n):
        k3.append(i1[i + 2])
    i = i + 3

print(i1)
print(k1)
print(k2)
print(k3)
    
k1m = sum(k1) / len(k1)
k2m = sum(k2) / len(k2)
k3m = sum(k3) / len(k3)
swap = True
while(swap):
    swap = False
    for i in k1:
        d1 = abs(i - k1m)
        d2 = abs(i - k2m)
        d3 = abs(i - k3m)
        if((d1<d2) and (d1<d3)):
            print(str(i) + " is correctly placed in a given cluster")
        elif(d2<d3):
            temp = k1.remove(i)
            k2.append(i)
            swap = True
        else:
            temp = k1.remove(i)
            k3.append(i)
            swap = True
    for i in k2:
        d1 = abs(i - k1m)
        d2 = abs(i - k2m)
        d3 = abs(i - k3m)
        if((d2<d1) and (d2<d3)):
            print(str(i) + " is correctly placed in a given cluster")
        elif(d1<d3):
            temp = k2.remove(i)
            k1.append(i)
            swap = True
        else:
            temp = k2.remove(i)
            k3.append(i)
            swap = True
    for i in k3:
        d1 = abs(i - k1m)
        d2 = abs(i - k2m)
        d3 = abs(i - k3m)
        if((d3<d1) and (d3<d2)):
            print(str(i) + " is correctly placed in a given cluster")
        elif(d1<d2):
            temp = k3.remove(i)
            k1.append(i)
            swap = True
        else:
            temp = k3.remove(i)
            k2.append(i)
            swap = True
    k1m = sum(k1) / len(k1)
    k2m = sum(k2) / len(k2)
    k3m = sum(k3) / len(k3)

print(i1)
print(k1)
print(k2)
print(k3)
